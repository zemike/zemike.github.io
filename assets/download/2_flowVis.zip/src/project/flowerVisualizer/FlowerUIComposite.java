package project.flowerVisualizer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.LinkedList;

public class FlowerUIComposite extends FlowerUIComponent{

	private LinkedList<FlowerUIComponent> children = new LinkedList<FlowerUIComponent>();
	private FlowerComposite flowerCompositeData;

	private boolean minimized = false;

	Font f = new Font("Monospaced", Font.BOLD, 12);

	@Override
	public ArrayList<FlowerUI> getFlowerUIList() {
		ArrayList<FlowerUI> toReturn = new ArrayList<FlowerUI>();
		for (FlowerUIComponent currentChild : children)
			toReturn.addAll(currentChild.getFlowerUIList());
		return toReturn;
	}

	@Override
	public FlowerUIComponent wrapAround(FlowerComponent wrapped) {
		FlowerComposite wrappedComposite = (FlowerComposite) wrapped;
		this.flowerCompositeData = wrappedComposite;
		for (FlowerComponent current : wrappedComposite.getChildren())
			this.children.add(current.makeUIWrap());
		return this;
	}

	@Override
	public void paintReuseGraphics(Graphics g, int x, int y) {
		super.paintReuseGraphics(g, x, y);
		g.translate(x, y);
		Shape clipTemp = g.getClip();
		g.setClip(0, 0, width-1, height-1);
		
		//Prints its name
		g.setColor(Color.DARK_GRAY);
		g.setFont(f);
		g.drawString(flowerCompositeData.getName(), 2, 14);

		//Draws the rectangle for itself
		g.setColor(flowerCompositeData.primaryColor);
		g.fillRect(0, 0, width-1, height-1);

		//Draws children
		int disx = flowerCompositeData.getOffsetSize();
		int disy = f.getSize()+4;
		if (!minimized) 
			for (FlowerUIComponent current : children)
			{
				current.paintReuseGraphics(g, disx, Math.max(disy, this.height - current.height));
				disx += current.width;
			}
		
		xPos = (int) ((Graphics2D) g).getTransform().getTranslateX();
		yPos = (int) ((Graphics2D) g).getTransform().getTranslateY();
		
		g.setClip(clipTemp);
		g.translate(-x, -y);
	}

	@Override
	public void validate() {
		super.validate();
		int newWidth = 2 * flowerCompositeData.getOffsetSize();
		int maxHeight = 10;
		for (FlowerUIComponent current : children)
			{
			current.validate();
			newWidth += current.getWidth();
			if (current.height > maxHeight)
				maxHeight = current.height;
			}
		width = minimized ? Math.min(50, newWidth) : newWidth;
		height = maxHeight + 2 * flowerCompositeData.getOffsetSize() + f.getSize();		
		//Comment out for never minimize height
		if (minimized)
			height = Math.min(200, height);
	}

	@Override
	public FlowerUIComposite getDeepestCompositeWithPoint(int x, int y) {
		if (isPointInside(x, y))
		{
			for (FlowerUIComponent child : children)
				if (child.isVisible() && child.getDeepestCompositeWithPoint(x, y) != null)
					return child.getDeepestCompositeWithPoint(x, y);
			return this;
		}
		return null;
	}
	
	public boolean isMinimized() {
		return minimized;
	}

	public void setMinimized(boolean minimized) {
		this.minimized = minimized;
		for (FlowerUIComponent child : children)
			child.setVisible(!minimized);
	}
	
	public void setVisible(boolean visible)
	{
		this.visible = visible;
		if (!minimized)
			for (FlowerUIComponent child : children)
				child.setVisible(visible);
	}
	
	//TODO: Test method.
	/**
	 * Unstable method of direct adding of a Component without wrapping.
	 * @param toAdd
	 */
	public void add(FlowerUIComponent toAdd){
		children.add(toAdd);
	}
	
	@Override
	public FlowerUIComponent getDeepestComponentWithPoint(int x, int y) {
		if (isPointInside(x, y))
			{
			for (FlowerUIComponent child : children)
				if (child.isVisible() && child.getDeepestComponentWithPoint(x, y) != null)
					return child.getDeepestComponentWithPoint(x, y);
			return this;
			}
		return null;
	}

	@Override
	public void propageteScale(double scalingFactor) {
		for (FlowerUIComponent child : children)
			child.propageteScale(scalingFactor);
	}
	
	public String toString(){
		if (flowerCompositeData!=null)
			return flowerCompositeData.getName();
		if (!children.isEmpty())
			return "an unnamed FlowerUIComposite with " +children.getFirst() + " inside";
		return	"empty FlowerUIComosite";
	}
	
}
