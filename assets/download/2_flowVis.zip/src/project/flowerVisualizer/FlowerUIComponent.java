package project.flowerVisualizer;

import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;


public abstract class FlowerUIComponent{

	protected int height;
	protected int width;
	
	protected int xPos;
	protected int yPos;
	
	protected boolean visible = true;
	
	public boolean isVisible() {
		return visible;
	}
	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	public int getHeight() {
		return height;
	}
	public int getWidth() {
		return width;
	}
	
	public Point getPos(){
		return new Point (xPos, yPos);
	}
	
	/**
	 * Asks Scaling of Flowers that are below this component in the tree.
	 * @param scalingFactor - a double to scale the flowers with.
	 */
	public abstract void propageteScale(double scalingFactor);
	
	/**
	 * Returns whether the specific point is inside the bounds of this UIComposite.
	 */
	public boolean isPointInside(int x, int y){
		return (x >= xPos && x<xPos+width && y >= yPos && y < yPos+height);
	}
	
	/**
	 * Finds the deepest UIComposite in the tree that contains the specific point (ignores FlowerUIs).
	 * @param x - x coordinate of the point.
	 * @param y - y coordinate of the point.
	 * @return - deepest UIComposite. If none exist, null is returned.
	 */
	public abstract FlowerUIComposite getDeepestCompositeWithPoint(int x, int y);
	
	/**
	 * Finds the deepest UIComponent in the tree that contains the specific point (searches for FlowerUI).
	 * @param x - x coordinate of the point.
	 * @param y - y coordinate of the point.
	 * @return - deepest UIComponent. If none exist, null is returned.
	 */
	public abstract FlowerUIComponent getDeepestComponentWithPoint(int x, int y);
	
	/**
	 * Flattens the tree to a FlowerUI list using tree traversal from left to right.
	 * @return A list containing only FlowerUIs.
	 */
	public abstract ArrayList<FlowerUI> getFlowerUIList();
	
	/**
	 * Wraps around a corresponding object (Flower, FlowerComponent, FlowerComposite). This should be done for the component to work properly!
	 * @param wrapped
	 * @return Self - makes wrapping easier.
	 */
	public abstract FlowerUIComponent wrapAround(FlowerComponent wrapped);
	
	/**
	 * Draws the component.
	 * @param g - Graphics to draw the component.
	 * @param x - horizontal displacement.
	 * @param y - vertical displacement.
	 */
	public void paintReuseGraphics(Graphics g, int x, int y){
		if (!visible)
			return;
	};
	
	/**
	 * Initializes the component to be drawn. Mostly sets the height and width.
	 */
	public void validate(){
//		if (!visible)
//		{
//			width = 0;
//			height = 0;
//		}
	};
}
