package project.flowerVisualizer;


import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Label;
import java.awt.Point;
import java.awt.ScrollPane;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;


public class FlowerVisualizerImpl implements FlowerVisualizer{

	final int DEFAULT_WIDTH = 640;
	final int DEFAULT_HEIGHT = 480;
	
	//Total number of opened windows.
	private static int windowsLeft = 0; 
	
	FlowerPanel myPanel;

	//A helper method not to have duplicate code
	private void drawFlowers(FlowerComposite flowerTree, ArrayList<Flower> flowerList, int width, int height,
			ArrayList<FlowerRelation> relationList)
	{
		//Removing flickering on resize - confirmed on Windows.
		//TODO: Confirm on Linux.
		//Toolkit.getDefaultToolkit().setDynamicLayout(true);
		//Toolkit.getDefaultToolkit().getDesktopProperty("awt.dynamicLayoutSupported");
		System.setProperty("sun.awt.noerasebackground", "true");
		
		Frame mainWindowFrame = new Frame();
		mainWindowFrame.setSize(width, height);
		mainWindowFrame.setBackground(Palette.CLOUDS);
		mainWindowFrame.add(new Label("Hallo"));
		mainWindowFrame.setLayout(new BorderLayout());
		
		windowsLeft += 1;

		mainWindowFrame.setTitle("It is Robotanism! Your code is filled with flowers~");
		Image myIcon = Toolkit.getDefaultToolkit().getImage("assets/icon0.png");
		mainWindowFrame.setIconImage(myIcon);
		
		//Need this to close the windows and decrease the total number of windows opened.
		mainWindowFrame.addWindowListener(new WindowAdapter(){
			@Override
			public void windowClosing(WindowEvent we)
			{
				FlowerVisualizerImpl.windowsLeft -= 1;
				we.getComponent().setVisible(false);
				if (FlowerVisualizerImpl.windowsLeft == 0)
					System.exit(0);
			}
		});

		
		myPanel = new FlowerPanel();
		
		//Adding Flowers
		if (flowerTree!=null)
			myPanel.add(flowerTree.makeUIWrap());
		else if (flowerList!=null)
			for (Flower currentFlower : flowerList)
				myPanel.add(currentFlower.makeUIWrap());
		
		myPanel.addRelations(relationList);
		myPanel.initiate();

		ScrollPane myScrollPane = new ScrollPane();
		myScrollPane.setWheelScrollingEnabled(false);
		myScrollPane.add(myPanel);
		mainWindowFrame.add(myScrollPane);
			
		MyMouseListener myMouseListener = new MyMouseListener();
		
		myScrollPane.addMouseListener(myMouseListener);
		myScrollPane.addMouseMotionListener(myMouseListener);
		
		mainWindowFrame.setVisible(true);
	}
	
	///The followings are the implementation of the interface that call each other in order to end up in the helper.
	@Override
	public void drawFlowers(FlowerComposite flowerTree, int width, int height,
			ArrayList<FlowerRelation> relationList) {
		drawFlowers(flowerTree, null, width, height, relationList);	
	}
	
	
	@Override
	public void drawFlowers(ArrayList<Flower> flowerList, int width,
			int height, ArrayList<FlowerRelation> relationList) {
			drawFlowers(null, flowerList, width, height, relationList);
	}
	
	@Override
	public void requestScale(int x, int y, int height, String middleText, String upperText){
		if (myPanel!=null)
			myPanel.prepareScale(x, y, height, middleText, upperText);
		myPanel.revalidate();
	}
	
	/**
	 * Changes how high the relation arrows are drawn - specific to this implementation.
	 * @param height - the maximum height above the highest flower in the relation that the arc reaches for neighboring flowers; 
	 * if there are k flowers in between, the the arc has (k + 1)*height instead.
	 */
	public void setRelationArcCoefficient(int height)
	{
		myPanel.setRelationArcCoefficient(height);
		myPanel.revalidate();
	}
	
	//Only works for ScrollPanes
	private class MyMouseListener extends MouseAdapter{
		int x, y, dx = 0, dy = 0;
		long when = 0;
		long whenCount = 0;
		final int REFRESHRATE = 1;
		
		@Override
		public void mouseDragged(MouseEvent arg0) {
			//System.out.println("Mouse Drag at "+ whenCount +"!");
			
			dx += arg0.getX() - x;
			dy += arg0.getY() - y;
			
			long dtime = arg0.getWhen() - when;
			//To avoid events out of order
			if (dtime > 0)
				{
				whenCount += dtime;
				when = arg0.getWhen();
				}
			
			if (whenCount > REFRESHRATE)
				movePanel(arg0.getComponent());
			
			x = arg0.getX();
			y = arg0.getY();
		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			x = arg0.getX();
			y = arg0.getY();
			when = arg0.getWhen();
			System.out.println("Mouse!");
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			movePanel(arg0.getComponent());
			System.out.println("Mouse Free!");
		}
		
		private void movePanel(Component where){
			ScrollPane scrollComp = ((ScrollPane) (where));
			Point transPoint = scrollComp.getScrollPosition();
			transPoint.translate(-dx, -dy);
			scrollComp.setScrollPosition(transPoint);
			dx = 0;
			dy = 0;
			whenCount = 0;
		}
	}
}
