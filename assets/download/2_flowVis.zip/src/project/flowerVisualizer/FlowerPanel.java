package project.flowerVisualizer;

import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

import javax.swing.SwingUtilities;

public class FlowerPanel extends Canvas implements AdjustmentListener{

	private int flowersWidth = 0;
	private int flowersHeight = 0;
	private int offset = 0;
	private int miny = 10;
	
	//How curvy is the arcs between the flowers.
	private int relationArcCoefficient = 40;
	

	protected ArrayList<FlowerUIComponent> components = new ArrayList<FlowerUIComponent>();
	private ArrayList<FlowerUI> flowers;
	private ArrayList<FlowerRelation> relations;
	private FlowerUIComposite rootUIComposite;
	
	private int scaleX, scaleY, scaleHeight;
	private String scaleMiddleString, scaleUpperString;
	
	private Dimension myDimension = new Dimension();
	private Image myImage;
	private Graphics buffer;
	
	private FlowerUIComponent mouseTargetComponent = rootUIComposite;
	
	/**
	 * Prepares a nice scale to show the number of lines of code involved.
	 * @param x - x coordinate of the bottom of the scale.
	 * @param y - y coordinate of the bottom. (Measured from the bottom of the panel.)
	 * @param height - height from the bottom of the scale to the top.
	 * @param middleText - text to be displayed at the middle of the scale.
	 * @param upperText - text to be displayed at the top of the scale.
	 */
	public void prepareScale(int x, int y, int height, String middleText, String upperText){
		scaleX = x;
		scaleY = y;
		scaleHeight = height;
		scaleMiddleString = middleText;
		scaleUpperString = upperText;
	}
	
	private static final long serialVersionUID = -4877282940745566348L;
	
	public FlowerPanel() {
		super();
		//Scrolling functionality
		MouseAdapter myListener = new FlowerPanelMouseAdapter();
		
		this.addMouseListener(myListener);
		this.addMouseMotionListener(myListener);
		this.addMouseWheelListener(myListener);
	}
	
	
	
	@Override
	//public void revalidate() {
	public void validate() {
		calcAndSetPreferredSize();
		
		myDimension.setSize(flowersWidth, flowersHeight);
		if (this.getParent() != null)
			myDimension.setSize(Math.max(flowersWidth,java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().width), 
					Math.max(this.getParent().getSize().height, flowersHeight));
//		myDimension = this.getParent().getSize();
		if (myImage != null)
			myImage.flush();
		myImage = createImage(myDimension.width, myDimension.height);
//		myImage = new BufferedImage (myDimension.width, myDimension.height, BufferedImage.TYPE_3BYTE_BGR);
		if (myImage!=null)
			buffer = myImage.getGraphics();
		//validate();
		//this.getParent().revalidate();
		
		if (buffer != null)
		{
			buffer.clearRect(0, 0, myDimension.width, myDimension.height);

			//Sun is an actual circle!
			buffer.setColor(Palette.SUN_FLOWER);
			int sunsize = 300;
			buffer.fillOval(-sunsize/2, -sunsize/2, sunsize, sunsize);

			offset = Math.max((getWidth() - flowersWidth)/2, 5);

			for (FlowerUIComponent current: components)
			{
				current.paintReuseGraphics(buffer, offset, Math.max(getHeight()-current.getHeight(), miny));
				offset+=current.getWidth();
			}

			if (relations!=null)
				for (FlowerRelation current: relations)
					drawRelation(current, buffer);

			drawScale(buffer);

			buffer.dispose();
		}
		//super.revalidate();
	}



	private void calcAndSetPreferredSize() {
		flowersHeight = 200;
			flowersWidth = 0;
			//flowers =  new ArrayList<FlowerUI>();
			
			for (FlowerUIComponent current:components)
				{
				current.validate();
				flowersWidth+=current.getWidth();
				if (current.getHeight() > flowersHeight)
					flowersHeight = current.getHeight();
				}
			this.setPreferredSize(new Dimension(flowersWidth, flowersHeight));
	}

	
	/**Required to be executed after all the FlowerComponents are added.
	 * Sets the sizes correctly.
	 */	
	//public void validate()
	public void initiate()
	{
		System.out.println("Validate is called.");
		
		flowersHeight = 200;
		flowersWidth = 0;
		flowers =  new ArrayList<FlowerUI>();
		rootUIComposite = new FlowerUICompositeRoot();		
		if (mouseTargetComponent == null) 
			mouseTargetComponent = rootUIComposite;
		
		for (FlowerUIComponent current:components)
			{
			current.validate();
			flowersWidth+=current.getWidth();
			if (current.getHeight() > flowersHeight)
				flowersHeight = current.getHeight();
			rootUIComposite.add(current);
			}
		flowers.addAll(rootUIComposite.getFlowerUIList());
		this.setPreferredSize(new Dimension(flowersWidth, flowersHeight));
		//System.out.println(flowersWidth + ", " + flowersHeight);
		//this.setSize(new Dimension(flowersWidth, flowersHeight));
		//this.repaint();
		
		///Double buffering validation
//		myDimension = getSize();
		myDimension.setSize(flowersWidth, flowersHeight);
		if (this.getParent() != null)
			myDimension.setSize(Math.max(flowersWidth,java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().width), 
					Math.max(this.getParent().getSize().height, flowersHeight));
//		myDimension = this.getParent().getSize();
		myImage = createImage(myDimension.width, myDimension.height);
		if (myImage!=null)
			buffer = myImage.getGraphics();
		
		
		if (buffer != null)
		{
			buffer.clearRect(0, 0, myDimension.width, myDimension.height);

			//Sun is an actual circle!
			buffer.setColor(Palette.SUN_FLOWER);
			int sunsize = 300;
			buffer.fillOval(-sunsize/2, -sunsize/2, sunsize, sunsize);

			offset = Math.max((getWidth() - flowersWidth)/2, 5);

			for (FlowerUIComponent current: components)
			{
				current.paintReuseGraphics(buffer, offset, Math.max(getHeight()-current.getHeight(), miny));
				offset+=current.getWidth();
			}

			if (relations!=null)
				for (FlowerRelation current: relations)
					drawRelation(current, buffer);

			drawScale(buffer);
			
			buffer.dispose();
		}
		
	}
	
	/**
	 * @param relationList - list of relations between the flowers
	 */
	public void addRelations(ArrayList<FlowerRelation> relationList){
		this.relations = relationList;
	};

	
	
	public void paint(Graphics g)
	{		
			
		g.drawImage(myImage, 0, 0, this);
//		g.dispose();
//		g.finalize();
	}
	
	public void update(Graphics g)
	{
		paint(g);
	}
	
	private void drawRelation(FlowerRelation relation, Graphics g)
	{
		if (!(flowers.get(relation.fromFlower).isVisible() && flowers.get(relation.toFlower).isVisible()))
			return;
		
		int leftIndex = Math.min(relation.fromFlower,relation.toFlower);
		int rightIndex = Math.max(relation.fromFlower,relation.toFlower);
		
		Point left = flowers.get(leftIndex).connectionCenter;
		Point right = flowers.get(rightIndex).connectionCenter;
		
		int maxheight = Math.min(left.y, right.y) - (rightIndex-leftIndex) * relationArcCoefficient;
		
		//Lifting the right relations not to have bidirectional coincide.
		if (relation.fromFlower>relation.toFlower)
			maxheight += relationArcCoefficient/4;
		
		((Graphics2D) g).setStroke(new BasicStroke(relation.connectionWidth));
		g.setColor(relation.getPrimaryColor());
		g.drawArc(left.x, maxheight, right.x-left.x, (left.y-maxheight)*2, 90, 90);
		g.drawArc(left.x, maxheight, right.x-left.x, (right.y-maxheight)*2, 0, 90);
		
		
		AffineTransform tempTrans = ((Graphics2D) g).getTransform();
		((Graphics2D) g).setStroke(new BasicStroke(relation.connectionWidth*5/6));
		//Drawing arrows
		double yt = 25;
		if (rightIndex == relation.toFlower)
		{
			//Drawing arrows on the right

			//Calculating the angle from the triangle
			//Obtaining local linearization of the oval	
			double xt =  (right.x-left.x)*Math.sqrt(1- Math.pow((yt/((right.y-maxheight)*2)), 2));
			double xtt = (right.x-left.x)-xt;
			double hypo = Point.distance(xtt, yt, 0, 0);
			double theta = Math.acos((yt)/hypo);

			g.translate(right.x, right.y);
			((Graphics2D) g).rotate(-Math.PI/2-theta);			
		}
		else
		{
			//Calculating the angle from the triangle
			//Obtaining local linearization of the oval	
			double xt =  (right.x-left.x)*Math.sqrt(1- Math.pow((yt/((left.y-maxheight)*2)), 2));
			double xtt = (right.x-left.x)-xt;
			double hypo = Point.distance(xtt, yt, 0, 0);
			double theta = Math.acos((yt)/hypo);

			g.translate(left.x, left.y);
			((Graphics2D) g).rotate(-Math.PI/2+theta);
		}
		g.drawLine(0, 0, 12, 5);
		g.drawLine(0, 0, 12, -5);
		((Graphics2D) g).setTransform(tempTrans);
	}

	
	public void drawScale(Graphics g){
		//Check for scale not set
		if (scaleHeight == 0 )
			return;
		
		g.setColor(Palette.setTransparency(Palette.MIDNIGHT_BLUE, 200));
		((Graphics2D) g).setStroke(new BasicStroke(2));
		g.drawLine(scaleX, this.getHeight() - scaleY, scaleX, this.getHeight()-scaleY-scaleHeight);
		
		g.drawString(scaleUpperString, scaleX-20, this.getHeight() - scaleY - scaleHeight-g.getFont().getSize());
		
		g.drawString(scaleMiddleString, scaleX-20, this.getHeight() - scaleY - (scaleHeight+g.getFont().getSize())/2);
	}
	
	public void add(FlowerUIComponent toAdd){
		components.add(toAdd);
	}
	
	public int getRelationArcCoefficient() {
		return relationArcCoefficient;
	}

	public void setRelationArcCoefficient(int relationArcCoefficient) {
		this.relationArcCoefficient = relationArcCoefficient;
	}

	@Override
	public void adjustmentValueChanged(AdjustmentEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	private void redoPicture(){
		invalidate();
		calcAndSetPreferredSize();
		revalidate();
		repaint();
	}

	private class FlowerPanelMouseAdapter extends MouseAdapter {
			private boolean isZoom = false;
	
			@Override
			public void mousePressed(MouseEvent e) {
				isZoom = false;
				mouseTargetComponent = rootUIComposite.getDeepestComponentWithPoint(e.getX(), e.getY());
				if (mouseTargetComponent == null)
					mouseTargetComponent = rootUIComposite;
				e.getComponent().getParent().dispatchEvent(SwingUtilities.convertMouseEvent(e.getComponent(), e, e.getComponent().getParent()));
			}
	
			@Override
			public void mouseDragged(MouseEvent e) {
				//e.getComponent().getParent().dispatchEvent(e);
				e.getComponent().getParent().dispatchEvent(SwingUtilities.convertMouseEvent(e.getComponent(), e, e.getComponent().getParent()));
			}
	
			@Override
			public void mouseClicked(MouseEvent e){
				if (isZoom)
					return;				
				System.out.println("Click!!!");
				FlowerUIComposite clickTarget = null;
				for (FlowerUIComponent current : ((FlowerPanel) e.getComponent()).components)
					clickTarget = current.getDeepestCompositeWithPoint(e.getX(), e.getY());
				if (clickTarget!=null)
					{
					clickTarget.setMinimized(!clickTarget.isMinimized());
					((FlowerPanel) e.getComponent()).redoPicture();
					}
			}
	
			@Override
			public void mouseReleased(MouseEvent e) {
				mouseTargetComponent = rootUIComposite;
				//e.getComponent().getParent().dispatchEvent(e);
				e.getComponent().getParent().dispatchEvent(SwingUtilities.convertMouseEvent(e.getComponent(), e, e.getComponent().getParent()));
			}
	
			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				isZoom = true;
				double scalingFactor = 1 + 0.10*Math.abs(e.getWheelRotation());
				//Reversing if it is a negative scaling
				if (e.getWheelRotation() < 0)
					scalingFactor = 1/scalingFactor;
				
				//Does scaling for all flowers
//				for (FlowerUI current:flowers)
//						current.getFlowerData().setScaleFactor((float) scalingFactor);
					
				System.out.println("Whell attempt for " + mouseTargetComponent + ".");
				mouseTargetComponent.propageteScale(scalingFactor);
				
				//For the future - scaling of the height meter.
				//((FlowerPanel) e.getComponent()).scaleHeight *= scalingFactor;
				
				//double x = ((java.awt.ScrollPane) (((FlowerPanel) e.getComponent()).getParent())).getScrollPosition().x *1.0 / ((FlowerPanel) e.getComponent()).getSize().width;
	//				double x = e.getX() *1.0 / ((FlowerPanel) e.getComponent()).getSize().width;
	//				System.out.println(x + ", "+ e.getX());
				
				//((FlowerPanel) e.getComponent()).invalidate();
				//((FlowerPanel) e.getComponent()).revalidate();
				//((FlowerPanel) e.getComponent()).invalidate();
				
	//				x *= ((FlowerPanel) e.getComponent()).getSize().width;
	//				System.out.println(x + ", "+ e.getX());
	//				Point tempPoint = (((java.awt.ScrollPane) (((FlowerPanel) e.getComponent()).getParent())).getScrollPosition());
	//				((java.awt.ScrollPane) (((FlowerPanel) e.getComponent()).getParent())).setScrollPosition(tempPoint.x, 1000);
				
				//calcAndSetPreferredSize();

				//((FlowerPanel) e.getComponent()).getParent().revalidate();
				
				//((FlowerPanel) e.getComponent()).revalidate();
				//((FlowerPanel) e.getComponent()).repaint();
				
				//((FlowerPanel) e.getComponent()).invalidate();
				//((FlowerPanel) e.getComponent()).revalidate();
				//((FlowerPanel) e.getComponent()).repaint();
				
				((FlowerPanel) e.getComponent()).redoPicture();
				
	//				x *= ((FlowerPanel) e.getComponent()).getSize().width;
	//				System.out.println(x + ", "+ e.getX());
	//				Point tempPoint = (((java.awt.ScrollPane) (((FlowerPanel) e.getComponent()).getParent())).getScrollPosition());
	//				((java.awt.ScrollPane) (((FlowerPanel) e.getComponent()).getParent())).setScrollPosition((int) x, tempPoint.y);
			}
		}
}