CppnSword - a generator of sword blades by Mikhail Baryshev.

Requires Java 8 (JRE or JDK - http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html )

The source is located at https://github.com/zemike/CppnSword

Enjoy!