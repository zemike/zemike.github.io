package project.flowerVisualizer;

public class FlowerUICompositeRoot extends FlowerUIComposite {

	@Override
	public boolean isVisible() {
		return true;
	}

	@Override
	public boolean isPointInside(int x, int y) {
		return true;
	}
	
	public String toString(){
		return "root " + super.toString();
	}

}
